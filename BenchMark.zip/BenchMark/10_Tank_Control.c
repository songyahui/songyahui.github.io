//https://create.arduino.cc/projecthub/zezarandrade/tank-control-with-arduino-a4d47f?ref=tag&ref_id=control&offset=10
// This routine let you to CONTROL level in a tank:
// Standard protocol to select instruments:
//Includes
#include "arduino.c"  //Servo Library can be used for Firgelli Mini Linear Actuators


void SendString (int InstrNr, int MW) 
  /*
    require true & Ready . (_^*) . Declare . (HIGH|LOW|Emp) . SendString^*
    ensure true & SendString
  */
 { 
Serial_print ("#");
Serial_print ("InstrNr");
Serial_print ("MM"); 
Serial_print ("MW"); 
Serial_print ("<");    
event ("SendString");
}

 void SendString1 (int InstrNr, int FF, int DD, int MM) 
  /*
    require true & Ready . (_^*) . Declare . (HIGH|LOW|Emp) . SendString . SendString
    ensure true & Emp
  */
 { 
Serial_print ("#");
Serial_print ("InstrNr");
Serial_print ("MM"); 
Serial_print ("FF");
Serial_print ("DD");
Serial_print ("MM"); 
Serial_print ("(<)") ;
}

void setup ()
 /*
    require true & Emp
    ensure true & Ready
  */
 {    // initialize serial communication at 9600 bits per second:
Serial_begin (9600);   
event ("Ready");
}

void loop () 
 /*
    require true & Ready . (_^*)
    ensure true & Declare . (HIGH|LOW|Emp) . SendString . SendString . SendString . SendString . SendString . SendString . Delay
  */
{
int RL = A0;    // select the input pin for the LEVEL potentiometer
int RSP = A1;    // select the input pin for the SET POINT potentiometer
int X = 8;      // select the pin for the pump control (ON - OFF)
int LEVEL = 0.0; // variable to store the value coming from RL
int SETPOINT = 0.0; // variable to store the value coming from RSP
 // declare X as an OUTPUT:
  pinMode(X, OUTPUT); 
  event ("Declare");
  // read the values from RL and RSP:
  LEVEL = analogRead (RL);
  SETPOINT = analogRead (RSP);
   // compare sensor values:
int FF;
int DD;
int MM;
  if (LEVEL < SETPOINT - 21){
     digitalWrite(X, HIGH);  
     event("HIGH");
    } 
  if (LEVEL < SETPOINT) {FF = 2;    } 
 if (LEVEL < SETPOINT) {MM = 0;    }   
   if (LEVEL > SETPOINT + 21) {
      digitalWrite(X, LOW);  
      event("LOW");
} 
 if (LEVEL > SETPOINT) {FF = 3 ;}   
  if (LEVEL > SETPOINT) {MM = 1 ;} 
float TRUE_LEVEL = LEVEL * (100.00 / 1023.00);
float TRUE_SETPOINT = SETPOINT * (100.00 / 1023.00);
  // print out the value you read:
 SendString (2, TRUE_LEVEL); // Instrument #02 – Vert_Meter
SendString (3, TRUE_LEVEL); // Instrument #03 – Tank_Meter
SendString1 (4, FF, DD, MM); // Instrument #04 - LED
SendString (5, TRUE_LEVEL); // Instrument #05 – Num_Display
SendString (6, TRUE_SETPOINT); // Instrument #06 - Num_Display
SendString (12, TRUE_LEVEL); // Instrument #12 - Trend
SendString (13, TRUE_SETPOINT); // Instrument #13 - Trend
delay (500);   
event ("Delay");
}


int main () 
 /*
    require Emp
    ensure true & Ready . 
    ((Declare . (HIGH|LOW|Emp) . SendString . SendString . SendString . SendString . SendString . SendString . Delay)^w)
  */
{
  while (1) {
    loop();
  }
}