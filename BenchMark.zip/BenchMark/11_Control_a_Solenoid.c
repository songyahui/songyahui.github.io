//https://create.arduino.cc/projecthub/robotgeek-projects-team/control-a-solenoid-with-arduino-710bdc?ref=tag&ref_id=control&offset=13
/*

Controlling a Solenoid with Arduino

This demo shows how to control a solenoid using pushbuttons and a relay with
your Arduino compatable controller.
 
 
 The circuit:
 * RobotGeek Pushbutton - Digital Pin 2
 * RobotGeek Pushbutton - Digital Pin 4
 * RobotGeek Pushbutton - Digital Pin 7
 * RobotGeek Relay - Digital Pin 8
 * RobotGeek Relay - Digital Pin 12
 * RobotGeek Relay - Digital Pin 13
 */
//Includes
#include "arduino.c"  //Servo Library can be used for Firgelli Mini Linear Actuators


// constants won't change. They're used here to set pin numbers:
const int button1Pin = 2;     // the number of the pushbutton1 pin
const int button2Pin = 4;     // the number of the pushbutton2 pin
const int button3Pin = 7;     // the number of the pushbutton3 pin
const int relay1Pin =  8;      // the number of the Relay1 pin
const int relay2Pin =  12;      // the number of the Relay2 pin
const int relay3Pin =  13;      // the number of the Relay3 pin

// variables will change:
int button1State = 0;         // variable for reading the pushbutton status
int button2State = 0;         // variable for reading the pushbutton status
int button3State = 0;         // variable for reading the pushbutton status

void setup() 
 /*
    require true & Emp
    ensure true & Emp
  */
{ 
  
  // initialize the pushbutton pin as an input:
  pinMode(button1Pin, INPUT);     
  pinMode(button2Pin, INPUT);     
  pinMode(button3Pin, INPUT);    
  // initialize the relay pin as an output:
  pinMode(relay1Pin, OUTPUT);    
  pinMode(relay2Pin, OUTPUT);    
  pinMode(relay3Pin, OUTPUT);    
   
}

void loop()
 /*
    require true & (_^*)
    ensure true & (Relay1High|Relay1Low|Emp) . (Relay2High|Relay2Low|Emp) . (Relay3High|Relay3Low|Emp) . ENDs
  */
{
  
  // read the state of the pushbutton values:
  button1State = digitalRead(button1Pin);
  button2State = digitalRead(button2Pin);
  button3State = digitalRead(button3Pin);

  // check if the pushbutton1 is pressed.
  // if it is we turn on the small relay/solenoid
  if (button1State == HIGH) {     
    // turn relay on:    
    digitalWrite(relay1Pin, HIGH);  
    event ("Relay1High");
  } 
  // When we let go of the button, turn off the relay
  else if ((button1State == LOW) && (digitalRead(relay1Pin) == HIGH)) {
    // turn relay off
    digitalWrite(relay1Pin, LOW); 
    event ("Relay1Low");
  }  
  
  // check if the pushbutton2 is pressed.
  // if it is we turn on the small relay/solenoid
  if (button2State == HIGH) {     
    // turn relay on:    
    digitalWrite(relay2Pin, HIGH); 
    event ("Relay2High"); 
  } 
  // When we let go of the button, turn off the relay
  else if ((button2State == LOW) && (digitalRead(relay2Pin) == HIGH)) {
    // turn relay off
    digitalWrite(relay2Pin, LOW); 
    event ("Relay2Low");
  }  

  // check if the pushbutton3 is pressed.
  // if it is we turn on the small relay/solenoid
  if (button3State == HIGH) {     
    // turn relay on:    
    digitalWrite(relay3Pin, HIGH);  
    event ("Relay3High");
  } 
  // When we let go of the button, turn off the relay
  else if ((button3State == LOW) && (digitalRead(relay3Pin) == HIGH)) {
    // turn relay off
    digitalWrite(relay3Pin, LOW); 
    event ("Relay3Low");
  }  
  event ("ENDs");

}


int main () 
 /*
    require Emp
    ensure true & (((Relay1High|Relay1Low|Emp) . (Relay2High|Relay2Low|Emp) . (Relay3High|Relay3Low|Emp) . ENDs)^w)
  */
{
  while (1) {
    loop();
  }
}