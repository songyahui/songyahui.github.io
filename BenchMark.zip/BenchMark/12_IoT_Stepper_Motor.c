//https://create.arduino.cc/projecthub/vicentezavala/iot-stepper-motor-2db08f?ref=tag&ref_id=control&offset=14
/*
*	Author		: Zavala Ortiz Vicente Arturo.
*	language	: .cpp
*	Created		: 3/11/2015 11:56:57 AM
*	Name		: ATmega32u4_WiFiStepperKnob.cpp
*	Update		: 1/9/2017 02:29:15 PM
*	Description : wifi Socket Client
*/
//Includes
#include "arduino.c"  //Servo Library can be used for Firgelli Mini Linear Actuators


/*****		wifi Global Variables		*****/
// Connection info data lengths
#define MAX_MSG_LEN							100
#define DHT11_PIN							0
#define FORWARD 0
#define SINGLE 0
#define BACKWARD 0 
// Constants

char ap_ssid[]				= "SSID of network";	    // SSID of network
char ap_password[]		= "Password of network";	// Password of network

unsigned int ap_security	= WLAN_SEC_WPA2;	  // Security of network
unsigned long timeout		  = 3000;            	// Milliseconds



// Global Variables
CC3000 wifi						= CC3000C;
CC3000_Client client  = CC3000_ClientC;

char in_message[MAX_MSG_LEN]	= {0};

/*****		Other Global Variables		*****/
static char page[20], data[20];
signed int option, value, out, stepper2_actual_value = 0;

void setup()
 /*
    require true & Emp
    ensure true & (CC3000Fail|CC3000OK) . Delay . (ErrorInfor|WifiConnect)
  */
{
	/* add setup code here */
 	ConnectionInfo connection_info;
 
 	// Initialize CC3000 (configure SPI communications) 	
 	Serial_begin(115200);
 	 
 	// Initialize CC3000 (configure SPI communications)
 	if(!wifi_init(9)) {
 			Serial_print("Initialize CC3000 FAIL!");
			 event ("CC3000Fail");
 		return;
 	}

	else {
		Serial_print ("Initialize CC3000 OK");
		event ("CC3000OK");
	}

	if(!wifi_connect(ap_ssid, ap_security, ap_password, timeout)) {	
		Serial_print("Error: Could not connect to AP!");
	}

	else
		return;
	
	
	delay(5000);
	event ("Delay");
	
	// Gather connection details and print IP address
	if(!wifi_getConnectionInfo(connection_info) )
	{
		Serial_print("Error: Could not obtain connection details");
		event ("ErrorInfor");
		return;
	}
	
	else 
	{	
		Serial_print("IP Address: ");
		printIPAddr("127.0.0.1");
		event ("WifiConnect");
	}

	delay(5000);
}

int i;

void loop()
 /*
    require true & (CC3000Fail|CC3000OK) . Delay . (ErrorInfor|WifiConnect) . (_^*)
    ensure true & ((NoMsg . NoMsg)|Recrive . (FORWARD|BACKWARD|Emp))
  */
{		
	/* add main program code here */
 	Serial_print("WAITING FOR MESSAGE!");

	fulsh_buffer(in_message);

	if(client_readfrom(4444, in_message, MAX_MSG_LEN) == -1) {
		Serial_print("NO MESSAGE RECEIVED");
		event ("NoMsg");
	}
	
	Serial_print(in_message);
  

  if(client_readfrom(4444, in_message, MAX_MSG_LEN) == -1) {
	  Serial_print("NO MESSAGE RECEIVED");
		event ("NoMsg");

  }

	else
	{
	  event ("Recrive");
		stepper2_setSpeed(200);

		if(http_gets(data, "stepper_motor2", in_message)) {
		  value = atoi(data);
							
			if(value > 0) {
				  stepper2_step(value, FORWARD, SINGLE);
					event ("FORWARD");
			}

			else if (value < 0) {
				  stepper2_step(value, BACKWARD, SINGLE);		
					event ("BACKWARD");		
			}
	}
	
	fulsh_buffer(in_message);
}
}





int main () 
 /*
    require Emp
    ensure true & (CC3000Fail|CC3000OK) . Delay . (ErrorInfor|WifiConnect) . Ready .
     (((NoMsg . NoMsg)|Recrive . (FORWARD|BACKWARD|Emp))^w)
  */

{
	setup ();
 	event ("Ready");
  while (1) {
    loop();
  }
}