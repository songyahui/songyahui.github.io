//https://create.arduino.cc/projecthub/Steve_Massikker/automatic-train-control-a17c6f?ref=tag&ref_id=control&offset=17
//Includes
#include "arduino.c"  //Servo Library can be used for Firgelli Mini Linear Actuators


// L298 
#define L298_ENA 5
#define L298_IN1 6
#define L298_IN2 7


// SCRIPTS VARIABLES
int counterScheduler;
unsigned long timerScheduler = 0;
unsigned long timerLocal = 0;
int speedAuto = 0;


void setup() 
 /*
    require true & Emp
    ensure true & Ready
  */
{

// Initializing pins
  pinMode(L298_ENA, OUTPUT);
  pinMode(L298_IN1, OUTPUT);
  pinMode(L298_IN2, OUTPUT);

// Set default direction to FORWARD
  digitalWrite(L298_IN1, HIGH);
  digitalWrite(L298_IN2, LOW); 
  event ("Ready");
}

void loop() 
 /*
    require true & Ready . Scheduler . (_^*)
    ensure true & (Scheduler|Emp) . ((Max5 . Start)|(Range10_15 . STP)|(Exact16 . Change)|(Range20_30 . Start)|(Range31_40 . STP)|(Min40 . Return)|Emp)
  */
{

  	// Start Scheduler
    if (millis() > (timerScheduler + 1000)) {  // Tick every 1 sec
      counterScheduler++; 
      timerScheduler = millis();
      event ("Scheduler");
    }  
    
    // ------------- SCRIPT SWING
    int brakingDelta = 5;
    int accelerateDelta = 6;

    // 1  | 0 > Time < 5 sec
    if (counterScheduler <= 5) {  
        // Start train
        event ("Max5");   

        if (millis() > (timerLocal + 100)) {
          if (speedAuto < 240) speedAuto = speedAuto + accelerateDelta;
          else speedAuto = 255;
          analogWrite(L298_ENA, speedAuto); 
          timerLocal = millis();
        }
        event ("Start");
    }       
    
    // 2  | 10 sec > Time < 15 sec
    if ((counterScheduler >= 10) && (counterScheduler <= 15)) {  // Stop train after 10 sec
        // Stop train
        event ("Range10_15");  
        if (millis() > (timerLocal + 100)) {
          if (speedAuto > 30) speedAuto = speedAuto - brakingDelta;
          else speedAuto = 0;
          analogWrite(L298_ENA, speedAuto); 
          timerLocal = millis();
        } 
        event ("STP");

    }  
    
    // 3  | Change direction
    if (counterScheduler == 16) {  
      event ("Exact16");  
        digitalWrite(L298_IN1, LOW);
        digitalWrite(L298_IN2, HIGH); 
        event ("Change");
    }   
    
    // 4  | 20 sec > Time < 30 sec
    if ((counterScheduler >= 20) && (counterScheduler <= 30)) {  
        event ("Range20_30");  
        // Start train
        if (millis() > (timerLocal + 100)) {
          if (speedAuto < 240) speedAuto = speedAuto + accelerateDelta;
          else speedAuto = 255;
          analogWrite(L298_ENA, speedAuto); 
          timerLocal = millis();
        } 
        event ("Start");
    }       
    
    // 5  | 31 sec > Time < 40 sec
    if ((counterScheduler >= 31) && (counterScheduler <= 40)) {  // Stop train
        // Stop train
        event ("Range31_40");  

        if (millis() > (timerLocal + 100)) {
          if (speedAuto > 30) speedAuto = speedAuto - brakingDelta;
          else speedAuto = 0;
          analogWrite(L298_ENA, speedAuto); 
          timerLocal = millis();
        } 
        event ("STP");
    }    
    
    // 6  | Return to Step 1
    if (counterScheduler > 40) {
        event ("Min40");  
        counterScheduler = 0;   
        digitalWrite(L298_IN1, HIGH);
        digitalWrite(L298_IN2, LOW); 
        event ("Return");
  	}
}

int main () 
 /*
    require Emp
    ensure true & Ready . (Scheduler . ((Scheduler|Emp) . ((Max5 . Start)|(Range10_15 . STP)
    |(Exact16 . Change)|(Range20_30 . Start)|(Range31_40 . STP)|(Min40 . Return)|Emp))^w)
  */
{
  setup() ;
  while (1) {
    if (1) { // this is ok, I just want to constructe an if else here. 
      event ("Scheduler");
      loop();

    }
  }
}