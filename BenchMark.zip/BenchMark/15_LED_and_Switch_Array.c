//https://create.arduino.cc/projecthub/ejshea/led-bar-graph-and-switch-array-8467e0?ref=tag&ref_id=control&offset=19
//Control LED bar graph function based on input from switch array
//Last modified April 2019

//Includes
#include "arduino.c"  //Servo Library can be used for Firgelli Mini Linear Actuators


int LED0 = 0;
int LED1 = 1;
int LED2 = 2;
int LED3 = 3;
int LED4 = 4;
int LED5 = 5;
int LED6 = 6;
int LED7 = 7;
int LED8 = 8;

int switch1 = 9;
int switch2 = 10;
int switch3 = 11;
int switch4 = 12;
int switch5 = 13;

int s1status = 0;
int s2status = 0;
int s3status = 0;
int s4status = 0;
int s5status = 0;

void setup() 
 /*
    require true & Emp
    ensure true & Ready
  */
{
  //set pins 0-8 as output
  pinMode(LED0, OUTPUT);
  pinMode(LED1, OUTPUT);
  pinMode(LED2, OUTPUT);
  pinMode(LED3, OUTPUT);
  pinMode(LED4, OUTPUT);
  pinMode(LED5, OUTPUT);
  pinMode(LED6, OUTPUT);
  pinMode(LED7, OUTPUT);
  pinMode(LED8, OUTPUT);

  //set pins 9-14 as input
  pinMode(switch1, INPUT);
  pinMode(switch2, INPUT);
  pinMode(switch3, INPUT);
  pinMode(switch4, INPUT);
  pinMode(switch5, INPUT);
  event ("Ready");

}

void loop() 
 /*
    require true & Ready . (_^*)
    ensure true & Read . (S11|S21|S31|S41|S5|Emp)
  */
{
  //check inputs from switches
  s1status = digitalRead(switch1);
  s2status = digitalRead(switch2);
  s3status = digitalRead(switch3);
  s4status = digitalRead(switch4);
  s5status = digitalRead(switch5);
  event ("Read");
  if(s1status == 1){
    event ("S11");
    //perform LED function 1 -- forward light
    
    digitalWrite(LED0, HIGH);
    delay(200);
    digitalWrite(LED0, LOW);
    digitalWrite(LED1, HIGH);
    delay(200);
    digitalWrite(LED1, LOW);
    digitalWrite(LED2, HIGH);
    delay(200);
    digitalWrite(LED2, LOW);
    digitalWrite(LED3, HIGH);
    delay(200);
    digitalWrite(LED3, LOW);
    digitalWrite(LED4, HIGH);
    delay(200);
    digitalWrite(LED4, LOW);
    digitalWrite(LED5, HIGH);
    delay(200);
    digitalWrite(LED5, LOW);
    digitalWrite(LED6, HIGH);
    delay(200);
    digitalWrite(LED6, LOW);
    digitalWrite(LED7, HIGH);
    delay(200);
    digitalWrite(LED7, LOW);
    digitalWrite(LED8, HIGH);
    delay(200);
    digitalWrite(LED8, LOW);
  }

  else if (s2status == 1){
    event ("S21");
    //perform LED function 2 -- group toggle

    //Turn ON LEDs 0-3, turn OFF 4-7
    digitalWrite(LED4, LOW);
    digitalWrite(LED5, LOW);
    digitalWrite(LED6, LOW);
    digitalWrite(LED7, LOW);
    digitalWrite(LED0, HIGH);
    digitalWrite(LED1, HIGH);
    digitalWrite(LED2, HIGH);
    digitalWrite(LED3, HIGH);
    delay(200);

    //Turn OFF LEDs 0-3, turn ON 4-7
    digitalWrite(LED0, LOW);
    digitalWrite(LED1, LOW);
    digitalWrite(LED2, LOW);
    digitalWrite(LED3, LOW);
    digitalWrite(LED4, HIGH);
    digitalWrite(LED5, HIGH);
    digitalWrite(LED6, HIGH);
    digitalWrite(LED7, HIGH);
    delay(200);
  }

  else if (s3status == 1){
    event ("S31");
    //perform LED function 3 -- backward light

    digitalWrite(LED8, HIGH);
    delay(200);
    digitalWrite(LED8, LOW);
    digitalWrite(LED7, HIGH);
    delay(200);
    digitalWrite(LED7, LOW);
    digitalWrite(LED6, HIGH);
    delay(200);
    digitalWrite(LED6, LOW);
    digitalWrite(LED5, HIGH);
    delay(200);
    digitalWrite(LED5, LOW);
    digitalWrite(LED4, HIGH);
    delay(200);
    digitalWrite(LED4, LOW);
    digitalWrite(LED3, HIGH);
    delay(200);
    digitalWrite(LED3, LOW);
    digitalWrite(LED2, HIGH);
    delay(200);
    digitalWrite(LED2, LOW);
    digitalWrite(LED1, HIGH);
    delay(200);
    digitalWrite(LED1, LOW);
    digitalWrite(LED0, HIGH);
    delay(200);
    digitalWrite(LED0, LOW);
  }

  else if (s4status == 1){
    event ("S41");
    //perform LED function 4 - forward and backward light

    //foward
    digitalWrite(LED0, HIGH);
    delay(200);
    digitalWrite(LED0, LOW);
    digitalWrite(LED1, HIGH);
    delay(200);
    digitalWrite(LED1, LOW);
    digitalWrite(LED2, HIGH);
    delay(200);
    digitalWrite(LED2, LOW);
    digitalWrite(LED3, HIGH);
    delay(200);
    digitalWrite(LED3, LOW);
    digitalWrite(LED4, HIGH);
    delay(200);
    digitalWrite(LED4, LOW);
    digitalWrite(LED5, HIGH);
    delay(200);
    digitalWrite(LED5, LOW);
    digitalWrite(LED6, HIGH);
    delay(200);
    digitalWrite(LED6, LOW);
    digitalWrite(LED7, HIGH);
    delay(200);
    digitalWrite(LED7, LOW);
    digitalWrite(LED8, HIGH);
    delay(200);
    digitalWrite(LED8, LOW);

    //backward
    digitalWrite(LED8, HIGH);
    delay(200);
    digitalWrite(LED8, LOW);
    digitalWrite(LED7, HIGH);
    delay(200);
    digitalWrite(LED7, LOW);
    digitalWrite(LED6, HIGH);
    delay(200);
    digitalWrite(LED6, LOW);
    digitalWrite(LED5, HIGH);
    delay(200);
    digitalWrite(LED5, LOW);
    digitalWrite(LED4, HIGH);
    delay(200);
    digitalWrite(LED4, LOW);
    digitalWrite(LED3, HIGH);
    delay(200);
    digitalWrite(LED3, LOW);
    digitalWrite(LED2, HIGH);
    delay(200);
    digitalWrite(LED2, LOW);
    digitalWrite(LED1, HIGH);
    delay(200);
    digitalWrite(LED1, LOW);
    digitalWrite(LED0, HIGH);
    delay(200);
    digitalWrite(LED0, LOW);
  }

  else if (s5status == 1){
    event ("S5");
    //perform LED function 5 -- Inward

    digitalWrite(LED0, HIGH);
    digitalWrite(LED7, HIGH);
    delay(200);
    digitalWrite(LED0, LOW);
    digitalWrite(LED7, LOW);
    digitalWrite(LED1, HIGH);
    digitalWrite(LED6, HIGH);
    delay(200);
    digitalWrite(LED1, LOW);
    digitalWrite(LED6, LOW);
    digitalWrite(LED2, HIGH);
    digitalWrite(LED5, HIGH);
    delay(200);
    digitalWrite(LED2, LOW);
    digitalWrite(LED5, LOW);
    digitalWrite(LED3, HIGH);
    digitalWrite(LED4, HIGH);
    delay(200);
    digitalWrite(LED3, LOW);
    digitalWrite(LED4, LOW);
    delay(200);
    
  }

  else{
    
    //perform default LED function if no switch is ON
    digitalWrite(LED0, LOW);
    digitalWrite(LED1, LOW);
    digitalWrite(LED2, LOW);
    digitalWrite(LED3, LOW);
    digitalWrite(LED4, LOW);
    digitalWrite(LED5, LOW);
    digitalWrite(LED6, LOW);
    digitalWrite(LED7, LOW);
  }

}

int main () 
 /*
    require Emp
    ensure true & Ready . ((Read . (S11|S21|S31|S41|S5|Emp))^w)
  */
{
  setup() ;
  while (1) {
    loop();
  }
}