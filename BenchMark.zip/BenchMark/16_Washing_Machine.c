#include "arduino.c"
/* 
https://github.com/joshua-scott/arduino-washing-machine/blob/master/washingmachine.c
ARDUINO WASHING MACHINE 
TASK REQUIREMENTS:

Implement a virtual washing machine with Arduino, relay, switches, led, seven segment display and motors.
- Motor1 simulates the drum of the washing machine. It should rotate whenever the machine is washing, rinsing or centrifuging. Otherwise it should be stopped.
- Motor2 simulates the water pump of the washing machine. It should rotate whenever water is pumped out of the machine. Otherwise it should be stopped.
- Switch1 is turning the machine ON/OFF.
- Switch2 simulates the sensor which is ‘1’ whenever there is enough water in the machine.
- Switch3 simulates the sensor which is ‘1’ whenever all the water is pumped out of the machine.
- Relay is ON when the machine takes water.

The routine of the washing machine goes like this:
1. Washing machine takes water for 3s
2. Washing machine is washing for 9s (The speed of the motor should be moderate)
3. Dirty water is pumped out of the machine for 3s
4. Washing machine takes water for 3s
5. Washing machine is rinsing for 5s
6. Rinsing water is pumped out of the machine for 3s
7. Washing machine is centrifuging for 5s (The speed of the motor should be high)
8. Led is blinking when the washing program is finished.
9. Washing machine can be turned OFF

*/

/* ----- OUTPUT MACROS ----- */




const int all[7] = {A, B, C, D, E, F, G};

/* ----- END OUTPUT MACROS ----- */

/* ----- SETUP ----- */

void setup() 
    /*
    require true & Emp
    ensure true & Ready
    */
{
  // Display outputs
  pinMode(A, OUTPUT);
  pinMode(B, OUTPUT);
  pinMode(C, OUTPUT);
  pinMode(D, OUTPUT);
  pinMode(E, OUTPUT);
  pinMode(F, OUTPUT);
  pinMode(G, OUTPUT);
  // Other outputs
  pinMode(RELAY, OUTPUT);
  pinMode(YELLOW, OUTPUT);
  pinMode(PUMP, OUTPUT);
  pinMode(DRUM, OUTPUT);
  pinMode(SWITCH2, OUTPUT);
  pinMode(SWITCH3, OUTPUT);
  event ("Ready");

}

/* ----- END SETUP ----- */

/* ----- DISPLAY ----- */


void TurnOffLED(int led)
    /*
    require (led >=0) /\  LedOn._* 
    ensure TRUE/\LedOff
    */
{
  digitalWrite(led, LOW);
  event ("LedOff");
}

void TurnOnLED(int led)
    /*
    require (led >1 \/ led <8)/\ emp   
    ensure TRUE/\LedOn
    */
{
  digitalWrite(led, HIGH);
  event ("LedOn");
}

void TurnOffAllLED(int n )
    /*
    require n >= 0 /\ emp   
    ensure TRUE/\LedOff^n
    */
{
  if (n < 0) return ;
  else digitalWrite(all[n], LOW);
       event ("LedOff");
       TurnOffAllLED(n -1);
/*
  for (int i = 0; i < sizeof(all); i++){
    digitalWrite(all[i], HIGH);
  }
*/
}

void DisplayDigit(int digit, int time, int n) 
    /*
    require (digit >=1 \/ digit <10) /\ time >=0 /\ n >= 0 /\ Ready._^*   
    ensure TRUE/\(LedOn)^*.Delay^time.LedOff^n
    */
{
  event("DisplayDigit");
  switch (digit) {
    case 0:
      TurnOnLED(A);
      TurnOnLED(B);
      TurnOnLED(C);
      TurnOnLED(D);
      TurnOnLED(E);
      TurnOnLED(F);
      break;
    case 1:
      TurnOnLED(B);
      TurnOnLED(C);
      break;
    case 2:
      TurnOnLED(A);
      TurnOnLED(B);
      TurnOnLED(G);
      TurnOnLED(E);
      TurnOnLED(D);
      break;
    case 3:
      TurnOnLED(A);
      TurnOnLED(B);
      TurnOnLED(G);
      TurnOnLED(C);
      TurnOnLED(D);
      break;
    case 4:
      TurnOnLED(F);
      TurnOnLED(G);
      TurnOnLED(B);
      TurnOnLED(C);
      break;
    case 5:
      TurnOnLED(A);
      TurnOnLED(F);
      TurnOnLED(G);
      TurnOnLED(C);
      TurnOnLED(D);
      break;
    case 6:
      TurnOnLED(A);
      TurnOnLED(C);
      TurnOnLED(D);
      TurnOnLED(E);
      TurnOnLED(F);
      TurnOnLED(G);
      break;
    case 7:
      TurnOnLED(A);
      TurnOnLED(B);
      TurnOnLED(C);
      break;
    case 8:
      TurnOnLED(A);
      TurnOnLED(B);
      TurnOnLED(C);
      TurnOnLED(D);
      TurnOnLED(E);
      TurnOnLED(F);
      TurnOnLED(G);
      break;
    case 9:
      TurnOnLED(A);
      TurnOnLED(B);
      TurnOnLED(C);
      TurnOnLED(D);
      TurnOnLED(F);
      TurnOnLED(G);
      break;
    default:
      event("DisplayDigit needs an int 0-9");
      break;
  }

  delay(time);
  TurnOffAllLED(n);    // remove digit
}

/* ----- END DISPLAY ----- */

/* ----- WASHING HELPER FUNCTIONS ----- */

void turnOnDrum() 
 /*
    require true & Ready . (_^*) . (wash|Rinse)
    ensure true & turnOnDrum
  */
{
  event("turnOnDrum");
  analogWrite(DRUM, 128);
}

void turnOnDrumFast() 
 /*
    require true & Ready . (_^*) . Centrufuge
    ensure true & turnOnDrumFast
  */
{
  event("turnOnDrumFast");
  analogWrite(DRUM, 255);
}

void turnOffDrum() 
 /*
    require true & Ready . (_^*) . turnOnDrum . (DisplayDigit . LedOn^* . LedOff^7)^*
    ensure true & turnOffDrum
  */
{
  event("turnOffDrum");
  analogWrite(DRUM, 0);
}

void turnOnPump() 
 /*
    require true & Ready . (_^*) . PumpWaterOut
    ensure true & turnOnPump
  */
{
  event("turnOnPump");
  analogWrite(PUMP, 255);
}

void turnOffPump() 
 /*
    require true & Ready . (_^*) . PumpWaterOut . turnOnPump . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7
    ensure true & turnOffPump
  */
{
  event("turnOffPump");
  analogWrite(PUMP, 0);
}

void turnOnRelay() 
 /*
    require true & Ready . (_^*) . letWaterIn
    ensure true & turnOnRelay
  */
{
  event("turnOnRelay");
  digitalWrite (RELAY, HIGH);
}

void turnOffRelay() 
 /*
    require true & Ready . (_^*) . letWaterIn . turnOnRelay . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7
    ensure true & turnOffRelay
  */
{
  event("turnOffRelay");
  digitalWrite (RELAY, LOW);
}

void setWaterStatus(int isFull) 
 /*
    require true & Ready . (_^*) . (turnOffRelay|turnOffDrum|turnOffPump)
    ensure true & (setWaterStatus: full|setWaterStatus: empty)
  */
{
  if (isFull) {
    event("setWaterStatus: full");
    analogWrite(SWITCH2, 255);
    analogWrite(SWITCH3, 0);
  } else {
    event("setWaterStatus: empty");
    analogWrite(SWITCH2, 0);
    analogWrite(SWITCH3, 255);
  }
}

void turnBothSwitchesOff() 
 /*
    require true & Ready . (_^*) . letWaterIn . turnOnRelay . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . turnOffRelay . setWaterStatus: full . wash . turnOnDrum . DisplayDigit . LedOn^6 . LedOff^7 .
    DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 .DisplayDigit . LedOn^4 . LedOff^7 .
    DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^3 . LedOff^7 .DisplayDigit . LedOn^7 . LedOff^7 .
    turnOffDrum . setWaterStatus: empty . PumpWaterOut . turnOnPump . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . turnOffPump . setWaterStatus: empty . letWaterIn . turnOnRelay . DisplayDigit . LedOn^6 . LedOff^7 . 
    DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . turnOffRelay . setWaterStatus: full .
    Rinse . turnOnDrum . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^4 . LedOff^7 . turnOffDrum . PumpWaterOut . turnOnPump . DisplayDigit . 
    LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . turnOffPump . setWaterStatus: empty . 
    Centrifuge . turnOnDrumFast . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 .
    DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^4 . LedOff^7 .turnOffDrum
    ensure true & Emp
  */
{
  analogWrite(SWITCH2, 0);  // green OFF
  analogWrite(SWITCH3, 0);   // red OFF
}

void forXSeconds(int seconds) 
 /*
    require true & Ready . (_^*) . (turnOnRelay|turnOnDrum|turnOnPump|turnOnDrumFast)
    ensure 1&((_^t1) . Ready)
  */
{
  // Show display for given time
  for (int i = 0; i < seconds; i++) {
    DisplayDigit(i, 1000, sizeof(all));
  } 
}

void blinkLed() 
    /*
    require TRUE/\emp
    ensure TRUE/\HIGH.Delay.LOW.Delay
    */
{
  digitalWrite(YELLOW, HIGH);
  delay(1);
  digitalWrite(YELLOW, LOW);
  delay(1);
}

/* ----- END WASHING HELPER FUNCTIONS ----- */

/* ----- WASHING CYCLE FUNCTIONS ----- */

void letWaterIn(int time) 
 /*
    require true & Ready . (_^*) . ((PumpWaterOut . turnOnPump . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . turnOffPump . setWaterStatus: empty)|Emp)
    ensure true & letWaterIn . turnOnRelay . (DisplayDigit . LedOn^*. LedOff^7)^* . turnOffRelay . setWaterStatus: full
  */
{
  event("letWaterIn");
  turnOnRelay();
  forXSeconds(time);
  turnOffRelay();
  setWaterStatus(1);
}

void wash(int time) 
 /*
    require true & Ready . (_^*) . letWaterIn . turnOnRelay . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . turnOffRelay . setWaterStatus: full
    ensure true & wash . turnOnDrum . (DisplayDigit . LedOn^*. LedOff^7)^* . turnOffDrum . setWaterStatus: empty
  */
{
  event("wash");
  turnOnDrum();
  forXSeconds(time);
  turnOffDrum();
  setWaterStatus(0);
}

void pumpWaterOut(int time) 
 /*
    require true & Ready . (_^*) . ((wash . turnOnDrum . DisplayDigit . LedOn^6 . LedOff^7 .
    DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 .DisplayDigit . LedOn^4 . LedOff^7 .
    DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^3 . LedOff^7 .DisplayDigit . LedOn^7 . LedOff^7 .
    turnOffDrum . setWaterStatus: empty)|(Rinse . turnOnDrum . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^4 . LedOff^7 . turnOffDrum))
    ensure true & PumpWaterOut . turnOnPump . (DisplayDigit . LedOn^*. LedOff^7)^* . turnOffPump . setWaterStatus: empty

  */
{
  event("PumpWaterOut");
  turnOnPump();
  forXSeconds(time);
  turnOffPump();
  setWaterStatus(0);
}

void rinse(int time) 
 /*
    require true & Ready . (_^*) . letWaterIn . turnOnRelay . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . turnOffRelay . setWaterStatus: full . wash . turnOnDrum . DisplayDigit . LedOn^6 . LedOff^7 .
    DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 .DisplayDigit . LedOn^4 . LedOff^7 .
    DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^3 . LedOff^7 .DisplayDigit . LedOn^7 . LedOff^7 .
    turnOffDrum . setWaterStatus: empty . PumpWaterOut . turnOnPump . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . turnOffPump . setWaterStatus: empty . letWaterIn . turnOnRelay . DisplayDigit . LedOn^6 . LedOff^7 . 
    DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . turnOffRelay . setWaterStatus: full
    ensure true & Rinse . turnOnDrum . (DisplayDigit . LedOn^* . LedOff^7)^* . turnOffDrum
  */
{
  event("Rinse");
  turnOnDrum();
  forXSeconds(time);
  turnOffDrum();
}

void centrifuge(int time) 
 /*
    require true & Ready . (_^*) . letWaterIn . turnOnRelay . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . turnOffRelay . setWaterStatus: full . wash . turnOnDrum . DisplayDigit . LedOn^6 . LedOff^7 .
    DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 .DisplayDigit . LedOn^4 . LedOff^7 .
    DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^3 . LedOff^7 .DisplayDigit . LedOn^7 . LedOff^7 .
    turnOffDrum . setWaterStatus: empty . PumpWaterOut . turnOnPump . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . turnOffPump . setWaterStatus: empty . letWaterIn . turnOnRelay . DisplayDigit . LedOn^6 . LedOff^7 . 
    DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . turnOffRelay . setWaterStatus: full .
    Rinse . turnOnDrum . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^4 . LedOff^7 . turnOffDrum . PumpWaterOut . turnOnPump . DisplayDigit . 
    LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . turnOffPump . setWaterStatus: empty
    ensure true & Centrifuge . turnOnDrumFast . (DisplayDigit . LedOn^*. LedOff^7)^* . turnOffDrum
  */
{
  event("Centrifuge");
  turnOnDrumFast();
  forXSeconds(time);
  turnOffDrum();
}

/* ----- END WASHING CYCLE FUNCTIONS ----- */

/* ----- LOOP ----- */

void loop() 
 /*
    require true & Ready . (_^*)
    ensure true & letWaterIn . turnOnRelay . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . turnOffRelay . setWaterStatus: full . wash . turnOnDrum . DisplayDigit . LedOn^6 . LedOff^7 .
    DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 .DisplayDigit . LedOn^4 . LedOff^7 .
    DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^3 . LedOff^7 .DisplayDigit . LedOn^7 . LedOff^7 .
    turnOffDrum . setWaterStatus: empty . PumpWaterOut . turnOnPump . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . turnOffPump . setWaterStatus: empty . letWaterIn . turnOnRelay . DisplayDigit . LedOn^6 . LedOff^7 . 
    DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . turnOffRelay . setWaterStatus: full .
    Rinse . turnOnDrum . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^4 . LedOff^7 . turnOffDrum . PumpWaterOut . turnOnPump . DisplayDigit . 
    LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . turnOffPump . setWaterStatus: empty . 
    Centrifuge . turnOnDrumFast . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 .
    DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^4 . LedOff^7 .turnOffDrum . Done ^w

  */
{
  letWaterIn(3);
  wash(9);
  pumpWaterOut(3);
  letWaterIn(3);
  rinse(5);
  pumpWaterOut(3);
  centrifuge(5);
  turnBothSwitchesOff();
  while (1) {
    event("Done");
    blinkLed();
  }
}

/* ----- END LOOP ----- */
int main () 
 /*
    require Emp
    ensure true & Ready . ((letWaterIn . turnOnRelay . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . turnOffRelay . setWaterStatus: full . wash . turnOnDrum . DisplayDigit . LedOn^6 . LedOff^7 .
    DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 .DisplayDigit . LedOn^4 . LedOff^7 .
    DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^3 . LedOff^7 .DisplayDigit . LedOn^7 . LedOff^7 .
    turnOffDrum . setWaterStatus: empty . PumpWaterOut . turnOnPump . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . turnOffPump . setWaterStatus: empty . letWaterIn . turnOnRelay . DisplayDigit . LedOn^6 . LedOff^7 . 
    DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . turnOffRelay . setWaterStatus: full .
    Rinse . turnOnDrum . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . 
    DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^4 . LedOff^7 . turnOffDrum . PumpWaterOut . turnOnPump . DisplayDigit . 
    LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . turnOffPump . setWaterStatus: empty . 
    Centrifuge . turnOnDrumFast . DisplayDigit . LedOn^6 . LedOff^7 . DisplayDigit . LedOn^2 . LedOff^7 .
    DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^5 . LedOff^7 . DisplayDigit . LedOn^4 . LedOff^7 .turnOffDrum . Done ^w)^w)
  */
{
  setup() ;
  while (1) {
    loop();
  }
}