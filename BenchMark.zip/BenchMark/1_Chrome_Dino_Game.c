//https://create.arduino.cc/projecthub/dokaniaharsh/t-rex-run-chrome-game-controller-042483?ref=tag&ref_id=control&offset=0
#include "arduino.c"

/*
In the below code we continuously read the analog value of the LDR sensor and if it comes inside 
the desired range for black (here : >270 & <400), we update the laststate variable to ‘1‘.

In the other case, first, we check if the laststate was 1 and print the same in the serial monitor 
for python code to read and next we update the laststate variable to 0.
*/

int val=0;
int laststate=0;

void setup() 
    /*
    require true & emp
    ensure true & Ready
    */
{
  // put your setup code here, to run once:

  pinMode(A0,INPUT);
  event ("Reday");
}

void innerLoop (int t) 
 /*
    require true & Read.Reset.(_^*) 
    ensure (t>270 \/ t < 400) & (Update^*).Return \/ (t <= 270 \/ t >= 400) & Return
  */

{
  if (t>270 && t<400) {
    val=analogRead(A0);
    laststate=1;
    event ("Update");
    innerLoop (val);
  }
  else {
      event ("Return");
      return; 
  }
}

void loop() 
 /*
    require true & Ready.(_^*) 
    ensure true & (Read . Reset . (Update^*) .  Return . (Delay|Emp))
  */

{
 
  val=analogRead(A0);
  event ("Read");

  laststate=0;
  event ("Reset");

  innerLoop (val);

  if(laststate==1)
  {  
     delay(10); 
     event ("Delay");
  }
}

int main () 
 /*
    require Emp
    ensure true & Ready . ((Read . Reset . (Update^*) .  Return . (Delay|Emp))^w)
  */

{
  while (1) {
    loop();
  }
}