//https://create.arduino.cc/projecthub/robotgeek-projects-team/control-a-large-linear-actuator-with-arduino-8a3953?ref=tag&ref_id=control&offset=2
/*

Linear Actuator Control using preset position
 
This demo shows how to do basic control of a large linear
actuator using an Arduino and two buttons. Each button is hard
coded with a preset position. Pressing a button will move
the actuator to that position.
 
 The circuit:
 * RobotGeek Pushbutton - Digital Pin 1
 * RobotGeek Pushbutton - Digital Pin 2
 * RobotGeek Relay - Digital Pin 4 
 * RobotGeek Relay - Digital Pin 7 
 
Products Used in this demo:
 - http://www.robotgeek.com/linear-actuators
 - http://www.robotgeek.com/robotgeek-geekduino-sensor-kit
 - http://www.robotgeek.com/robotGeek-pushbutton
 - http://www.robotgeek.com/robotgeek-relay
 
 */
//Includes
#include "arduino.c"  //Servo Library can be used for Firgelli Mini Linear Actuators


// constants won't change. They're used here to set pin numbers:
const int button1Pin = 2;     // the number of the pushbutton1 pin
const int button2Pin = 4;     // the number of the pushbutton2 pin
const int relay1Pin =  7;      // the number of the Realy1 pin
const int relay2Pin =  8;      // the number of the Relay2 pin
const int sensorPin = 0;    // select the input pin for the potentiometer

// variables will change:
int button1State = 0;         // variable for reading the pushbutton status
int button2State = 0;         // variable for reading the pushbutton status
int sensorValue = 0;  // variable to store the value coming from the sensor

int goalPosition = 350; 
int CurrentPosition = 0; 
int Extending = 0;
int Retracting = 0;

void setup() 
    /*
    require true & emp
    ensure true & Ready
    */
{ 

  //start serial connection


  // initialize the pushbutton pin as an input:
  pinMode(button1Pin, INPUT);     
  pinMode(button2Pin, INPUT);    
  // initialize the relay pin as an output:
  pinMode(relay1Pin, OUTPUT);    
  pinMode(relay2Pin, OUTPUT);    
  
  //preset the relays to LOW
  digitalWrite(relay1Pin, LOW); 
  digitalWrite(relay2Pin, LOW); 

  event ("Ready");
  
}

void loop()
    /*
    require true & Ready . (_^*)
    ensure true & Print . (Extending|Retracting|Emp) . (Extending|Retracting|Emp) . (IDLE|Emp)
    */
{
  
  // read the value from the sensor:
  CurrentPosition = analogRead(sensorPin); 

  
  // print the results to the serial monitor:
  event ("Print");
  
  // read the state of the pushbutton values:
  button1State = digitalRead(button1Pin);
  button2State = digitalRead(button2Pin);

  if (button1State == HIGH) {     
    // set new goal position
    goalPosition = 300; 
    
    if (goalPosition > CurrentPosition) {
        Retracting = 0;
        Extending = 1;
        digitalWrite(relay1Pin, HIGH);  
        digitalWrite(relay2Pin, LOW);  
        event("Extending");     
    }      
    else if (goalPosition < CurrentPosition) {
        Retracting = 1;
        Extending = 0;
        digitalWrite(relay1Pin, LOW);  
        digitalWrite(relay2Pin, HIGH); 
        event("Retracting");         
    }  
  }

  if (button2State == HIGH) {     
    // set new goal position
    goalPosition = 500; 
    
    if (goalPosition > CurrentPosition) {
        Retracting = 0;
        Extending = 1;
        digitalWrite(relay1Pin, HIGH);  
        digitalWrite(relay2Pin, LOW);  
        event("Extending");   
    }        
    else if (goalPosition < CurrentPosition) {
        Retracting = 1;
        Extending = 0;
        digitalWrite(relay1Pin, LOW);  
        digitalWrite(relay2Pin, HIGH); 
        event("Retracting");         
    }  
  }



  if (Extending == 1 && CurrentPosition > goalPosition) {
    //we have reached our goal, shut the relay off
    digitalWrite(relay1Pin, LOW); 
    int Extending = 0; 
    event("IDLE");  
  }
  
  if (Retracting == 1 && CurrentPosition < goalPosition){
    //we have reached our goal, shut the relay off
    digitalWrite(relay2Pin, LOW); 
    int Retracting = 0; 
    event("IDLE");  
  }
 
}

int main () 
 /*
    require Emp
    ensure true & Ready . ((Print . (Extending|Retracting|Emp) . (Extending|Retracting|Emp) . (IDLE|Emp))^w)
  */
{
  while (1) {
    loop();
  }
}