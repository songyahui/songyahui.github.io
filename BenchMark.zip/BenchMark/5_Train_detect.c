//https://create.arduino.cc/projecthub/Steve_Massikker/using-ir-hall-type-sensors-for-train-detection-210f53?ref=tag&ref_id=control&offset=3
//Includes
#include "arduino.c"  //Servo Library can be used for Firgelli Mini Linear Actuators


int trigger_s1, trigger_s2, latch_s1, latch_s2; 

#define LED_BUILTIN 0

void setup() 
 /*
    require true & Emp
    ensure true & Ready
  */
{
  pinMode(LED_BUILTIN, OUTPUT);
  pinMode(9, INPUT);
  pinMode(10, INPUT); 
  event ("Ready");
}

void loop() 
 /*
    require true & Ready . (_^*)
    ensure true & ((S1_1 . Latch1_1)|S1_0) . ((S2_2 . Latch2_1)|S2_0) . ((Latch1_0 . Latch2_0)|Emp) . (High|Low)
  */
{

  if (digitalRead(10) == HIGH) {
    trigger_s1 = 1;
    event ("S1_1");
    latch_s1 = 1;
    event ("Latch1_1");
  }   
  else {
    trigger_s1 = 0;
    event ("S1_0");
  }
    
  if (digitalRead(9) == HIGH) {
    trigger_s2 = 1;
    latch_s2 = 1; 
    event ("S2_1");
    event ("Latch2_1");
  }
  else {
    trigger_s2 = 0;  
    event ("S2_0");
  }

  if (latch_s1 && latch_s2 && !trigger_s1 && !trigger_s2) {
    latch_s1 = 0;    
    latch_s2 = 0;  
    event ("Latch1_0");
    event ("Latch2_0");   
  }

  if (latch_s1 || latch_s2) {
    digitalWrite(LED_BUILTIN, HIGH);
    event ("High");
  }
  else {
    digitalWrite(LED_BUILTIN, LOW);
    event ("Low");
  }
  
}

int main () 
 /*
    require Emp
    ensure true & Ready . ((((S1_1 . Latch1_1)|S1_0) . ((S2_2 . Latch2_1)|S2_0) . ((Latch1_0 . Latch2_0)|Emp) . (High|Low))^w)
  */
{
  while (1) {
    loop();
  }
}