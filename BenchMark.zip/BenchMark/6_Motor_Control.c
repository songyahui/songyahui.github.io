//https://create.arduino.cc/projecthub/ahmedsoliman163/control-speed-and-direction-of-motor-6f09c2?ref=tag&ref_id=control&offset=4

//Includes
#include "arduino.c"  //Servo Library can be used for Firgelli Mini Linear Actuators

int lcd [6] = {13, 12, 11, 10, 9, 8};                                                  

//pin 1 in  LCD 1 >>>>>>>>>>>>> ground
//pin 2 in  LCD 2 >>>>>>>>>>>>> vcc
//pin 3 in  LCD 3 >>>>>>>>>>>>> ground
//pin 4 in  LCD 4 >>>>>>>>>>>>> 13
//pin 5 in  LCD 5>>>>>>>>>>>>> ground                               // LCD connection
//pin 6 in  LCD 6 >>>>>>>>>>>>> 12
//pin 7 in  LCD 7 >>>>>>>>>>>>> NO
//pin 8 in  LCD 8 >>>>>>>>>>>>> NO
//pin 9 in  LCD 9 >>>>>>>>>>>>> NO
//pin 10 in LCD 10 >>>>>>>>>>>>> NO
//pin 11 in LCD 11  >>>>>>>>>>>>> 11
//pin 12 in LCD 12 >>>>>>>>>>>>> 10
//pin 13 in LCD 13 >>>>>>>>>>>>> 9
//pin 14 in LCD 14 >>>>>>>>>>>>> 8
//pin 15 in LCD 15 >>>>>>>>>>>> vcc
//pin 16 in LCD 16 >>>>>>>>>>>  ground
//******************************************************************************************************
const int In1 = A1;     //pin  5 in lm298 >>>>>>>> A1 in arduino
const int In2 = 7;      //pin  7 in lm298 >>>>>>>> 7 in arduino           // L298 motor driver connection
const int En = 6;       //pin  6 in lm298 >>>>>>>> 6(PWM) in arduino
                        // pin 2 in l298  >>>>>>>> Motor pin
                        // pin 3 in l298  >>>>>>>> Motor pin 
                        // pin 9  in l298  >>>>>>>>> 5 volt
                        // pin 4  in l298  >>>>>>>>> Motor voltage
                        //pin  8  in l298  >>>>>>>>> ground
//**********************************************************************************************************
const int Pot = A0;        //pin at middle in variable resistance >>>>>>>> A0 in arduino          // variable resistance  connection
                           // others pin to VCC & Ground  
//**************************************************************************************************************
const int SW = 5;          //vcc (5 Volt )  switch for direction with (resistance 10 k to ground )  >>>>>>>>>>>> 5 in arduino     // switch connection

//**********************************************************************************************************************
const int red_led = 2;      // led with resistance 330 ohm to >>>>>>>>>> 2 in arduino                 
const int yellow_led = 3;   // led with resistance 330 ohm to >>>>>>>>>> 3 in arduino                 //LED connection 
const int green_led = 4;   // led with resistance 330 ohm to >>>>>>>>>> 4 in arduino                  
//***********************************************************************************************************************
volatile float pot_read = 0.0;
volatile int i = 0;
int flag = 1;
//**********************************************************************************************
void red() 
 /*
    require true & Ready . Delay . Red . (_^*) . STP
    ensure true & Red
  */
{
  event ("Red");
  digitalWrite(red_led, HIGH);                         // open RED LED 
  digitalWrite(yellow_led, LOW);
  digitalWrite(green_led, LOW);
}
//*********************************************
void yellow() 
 /*
    require true & Ready . Delay . Red . (_^*) . CCW
    ensure true & Yellow
  */
{
  event ("Yellow");
  digitalWrite(red_led, LOW);                           // open yellow LED 
  digitalWrite(yellow_led, HIGH);
  digitalWrite(green_led, LOW);
}
//**********************************************************************************
void green() 
 /*
    require true & Ready . Delay . Red . (_^*) . CW
    ensure true & Green
  */
{     
  event ("Green");                                        
  digitalWrite(red_led, LOW);                                 // open Green  LED 
  digitalWrite(yellow_led, LOW);
  digitalWrite(green_led, HIGH);
}
//*****************************************************************************
void CW() 
 /*
    require true & Ready . Delay . Red . (_^*)
    ensure true & CW
  */
{
  event ("CW");
  digitalWrite(In1, HIGH);
  digitalWrite(In2, LOW);                                   // Make motor run in Clock wise direction 

}
//*********************************************************************************
void CCW() 
 /*
    require true & Ready . Delay . Red . (_^*) . Green
    ensure true & CCW
  */
{
  event ("CCW");
  digitalWrite(In2, HIGH);
  digitalWrite(In1, LOW);                                           // Make motor run in counter  Clock wise direction 

}
//****************************************************************************
void STP() 
 /*
    require true & Ready . Delay . Red . (_^*) . Yellow
    ensure true & STP
  */
{
  event ("STP");
  digitalWrite(In1, LOW);
  digitalWrite(In2, LOW);                                         // Make motor STOP 

}
//************************************************************************************
//Make input and output pins 
void setup() 
 /*
    require true & Emp
    ensure true & Ready
  */
{
  // put your setup code here, to run once:
  delay(1000);
  pinMode(In1, OUTPUT);
  pinMode(In2, OUTPUT);
  pinMode(En, OUTPUT);
  pinMode(red_led, OUTPUT);
  pinMode(yellow_led, OUTPUT);
  pinMode(green_led , OUTPUT);
  pinMode(SW, INPUT);
  pinMode(Pot, INPUT);
  event("Ready");

}


void innerLoop (int index) 
 /*
    require true & Ready . Delay . Red . (_^*)
    ensure true & ((CW . Green . CCW . Yellow . STP . Red)|Emp)^*
  */
{
  if (digitalRead(SW)==1) {
    i++;
    switch (i)
    {
      case 1:
        CW();

        green();

        break;
      case 2:
        CCW();
        
        yellow();
        
        break;
      case 3:
        STP();
        red();
        
        i = 0;
        break;
    }
    innerLoop (index + 1);
  }
  else {
    return ;
  }
}


//*******************************************************************************
void loop() 
 /*
    require true & Ready . (_^*)
    ensure true & Delay . Red . ((CW . Green . CCW . Yellow . STP . Red)|Emp)^*
  */
{
  pot_read = analogRead(Pot);                            // read variable resistance
  pot_read = pot_read / 4.0;
  pot_read = pot_read / 254.0;
  pot_read = pot_read * 100.0;

  delay(20);
  event("Delay");

  analogWrite(En, pot_read);


  event("Red");


  //  Serial.print(" pot_read= ");
  //  Serial.println( pot_read );
  innerLoop (i);
  

}


int main () 
 /*
    require Emp
    ensure true & Ready . ((Delay . Red . ((CW . Green . CCW . Yellow . STP . Red)|Emp)^*)^w)
  */
{
  while (1) {
    loop();
  }
}