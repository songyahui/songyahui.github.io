//https://create.arduino.cc/projecthub/Steve_Massikker/arduino-train-demo-2-67d8a0?ref=tag&ref_id=control&offset=5
// L298
#define IN1_PIN 4
#define IN2_PIN 5
#define ENA_PIN 9

//Includes
#include "arduino.c"  //Servo Library can be used for Firgelli Mini Linear Actuators

#define LED_BUILTIN 0
#define B11111000 0
#define B00000100 0

// VARIABLES //
int flag_LED = 0;
int stringComplete = 0;
char inputString [100] = ""; 

void setup() 
 /*
    require true & Emp
    ensure true & Ready
  */
{

// Initializing Serial

// Initializing Motor-Driver
  pinMode(ENA_PIN, OUTPUT); 
  pinMode(IN1_PIN, OUTPUT); 
  pinMode(IN2_PIN, OUTPUT);
  pinMode(LED_BUILTIN, OUTPUT);
  
// Set PWM frequency for D9 & D10
// Timer 1 divisor to 256 for PWM frequency of 122.55 Hz
  int TCCR1B = TCCR1B & B11111000 | B00000100;   
  event ("Ready"); 

}

void loop() 
 /*
    require true & Ready . (_^*)
    ensure true & (((Write0_120|Write140_225|Forward|Backward|STOP|Emp) . Complete0)|Emp) . (High|Low)
  */
{

  if (stringComplete) {

    if (inputString_charAt(0) =='a') {

      //THROTTLE 
      // Speed 
      if (inputString_charAt(1) =='0') {
        if (inputString_charAt(2) =='0') analogWrite(ENA_PIN, 0);
        if (inputString_charAt(2) =='2') analogWrite(ENA_PIN, 60);
        if (inputString_charAt(2) =='4') analogWrite(ENA_PIN, 80);
        if (inputString_charAt(2) =='6') analogWrite(ENA_PIN, 100);
        if (inputString_charAt(2) =='8') analogWrite(ENA_PIN, 120);
        event ("Write0_120");
      } 
      if (inputString_charAt(1) =='1') {
        if (inputString_charAt(2) =='0') analogWrite(ENA_PIN, 140);
        if (inputString_charAt(2) =='2') analogWrite(ENA_PIN, 170);
        if (inputString_charAt(2) =='4') analogWrite(ENA_PIN, 200);
        if (inputString_charAt(2) =='6') analogWrite(ENA_PIN, 230);
        if (inputString_charAt(2) =='8') analogWrite(ENA_PIN, 255);
        event ("Write140_225");
      }      

      // DIRECTION
      if (inputString_charAt(1) =='d') {
        if (inputString_charAt(2) =='f') { // (f) Forward
          digitalWrite(IN1_PIN, HIGH);
          digitalWrite(IN2_PIN, LOW);
          event ("Forward");
        }
        if (inputString_charAt(2) =='b') { // (b) Backward
          digitalWrite(IN1_PIN, LOW);
          digitalWrite(IN2_PIN, HIGH);
          event ("Backward");
        }
        if (inputString_charAt(2) =='s') { // (s) Stop button
          digitalWrite(IN1_PIN, LOW);
          digitalWrite(IN2_PIN, LOW);
          analogWrite(ENA_PIN, 0);
          flag_LED = !flag_LED;
          event ("STOP");
        }
      }
    }

    * inputString = ' ';
    stringComplete = 0;
    event ("Complete0");
  }

  if (flag_LED) {
    event ("High");
    digitalWrite(LED_BUILTIN, HIGH);
  }
  else {
    event ("Low");
    digitalWrite(LED_BUILTIN, LOW);
  }
}

void serialEvent() 
 /*
    require true & Emp
    ensure true & Emp
  */
{
  while (available()) {
    char inChar = (char)read();
    *  inputString += inChar;
    if (inChar == 'z') {
      stringComplete = 1;
    }
  }
}


int main () 
 /*
    require Emp
    ensure true & Ready . (((((Write0_120|Write140_225|Forward|Backward|STOP|Emp) . Complete0)|Emp) . (High|Low))^w)
  */
{
  while (1) {
    loop();
  }
}