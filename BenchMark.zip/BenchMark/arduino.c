#include "primitives.c"
#include <time.h>

#define INPUT 0
#define OUTPUT 1
#define HIGH 1
#define LOW 1
#define A0 0
#define A1 1
#define A2 2
#define A3 3
#define A4 4
#define A5 5

#define A 2
#define B 8
#define C 6
#define D 5
#define E 4
#define F 3
#define G 7
#define M 3

#define RELAY 10
#define YELLOW 12
#define PUMP 9
#define DRUM 11
#define SWITCH2 0
#define SWITCH3 1

#define WLAN_SEC_WPA2 0


#define CC3000C 0
#define CC3000_ClientC 0

typedef int CC3000;

typedef int CC3000_Client;

typedef int ConnectionInfo;

int wifi_connect (char * a, int b, char * c, int d) {
    return 0;
}
int wifi_getConnectionInfo (a) {
    return 0;
}

int client_readfrom (int a, char * b, int c) {
    return 0;
}

int stepper2_step (int a, int b, int c){
    return 0;
}

int stepper2_setSpeed (int a){
    return 0;
}

int wifi_init (a) {
    return 0;
}

void pinMode (int a, int b){
    return ;
}

void digitalWrite (int a, int b){
    return ;
}

int  digitalRead (int a){
    return 0;
}

void delay (int n) 
    /*
    require (n>=0)/\/\emp
    ensure (n>=0)/\(Delay^n)
    */
{
    if (n == 0) { 
        return;
    }
    else {
        event ("Delay"); 
        delay (n - 1);
    }
} 

void analogWrite(int a, int b)
    /*
    require (a>=0)/\/\emp
    ensure (b=1/\HIGH) \/ (b=0/\LOW)
    */
{
    return ;
}


int  analogRead(int a){
    int lower = 210, upper = 220; 
  
    // Use current time as  
    // seed for random generator 
    /*srand(time(0)); 
  
    return (rand() % 
           (upper - lower + 1)) + lower;
           */
    return 0;
}

int random (int a , int b ){
    return 0;
}



int millis() {
    return 0;
}

int myservo1_read (){
    return 0;
}

int myservo2_read (){
    return 0;
}

void  myservo1_write(int a) {

}

void  myservo2_write(int a) {

}

void  linearKnob_writeMicroseconds(int a) {

}

void  linearSlider_writeMicroseconds(int a) {

}

void    linearButton_writeMicroseconds(int a) {

}

void  linearJoystick_writeMicroseconds(int a) {

}


void  linearKnob_attach(int a) {

}

void  linearSlider_attach(int a) {

}

void    linearButton_attach(int a) {

}

void  linearJoystick_attach(int a) {

}

int constrain (int a, int b, int c){
 return 0;
}

int map (int a, int b, int c, int d, int e){
    return 0;
}

int available ( ){
    return 1;
}


char read() {
    return ' ';
}


int inputString_charAt (int a) {
    return 1;
}

void attachInterrupt (int a, int c) {
    return ;
}

void Serial_print (char * a){
    return ;
}   

void Serial_begin (int a){
    return ;
} 

void printIPAddr (char * a) {
    return ;
}

void fulsh_buffer (char * a){
    return ;
}

int http_gets (char * a, char * b, char * c){
    return 0;
}


int atoi (char * c){
    return 0;
}