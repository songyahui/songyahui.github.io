#include <stdio.h>

void event (char * ev)

{
    printf ("%s\n",ev);
}
