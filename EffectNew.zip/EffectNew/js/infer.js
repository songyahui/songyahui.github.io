/* function onLoadTxtArea() {
	var fileName = getParam('ex');
	var fileType = getParam('type');
	var fileOptions = getParam('options');
	if (fileName != "0") {
		var fileLocation = (fileType == "ss")?"src/hip/":"src/sleek/";
		var filePath = fileLocation + fileName + "." + fileType;
		loadFile(filePath);
	} else {
		var txtArea = document.getElementById('program_container')
			|| document.getElementById('program_container');
		txtArea.value = "// Enter your own example here.";
	}
	var nameField = document.getElementById('program_name')
		|| document.getElementById('program_name');
	nameField.value = fileName;
	var typeField = document.getElementById('program_type')
		|| document.getElementById('program_type');
	typeField.value = fileType;
	var optionsField = document.getElementById('program_options')
		|| document.getElementById('program_options');
	optionsField.value = fileOptions;
	var resultFrame = window;
        resultFrame.location.href='result.html';
	editAreaLoader.init({
		id: "program_container"
		,allow_resize: "both"
		,word_wrap: true
		,syntax: "cpp"
	});
} */

function getParam(name) {
	name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
	var regexS = "[\\?&]"+name+"=([^&#]*)";
	var regex = new RegExp( regexS );
	var results = regex.exec( window.location.href );
	if( results == null )
		return "";
	else
		return results[1];
}

function loadFileResult(fileLocation,container) {
	var srcFile = new XMLHttpRequest();
	srcFile.open("GET", fileLocation, true);
	srcFile.onreadystatechange = function() {
		if (srcFile.readyState === 4) {
			if (srcFile.status === 200) {
				allText = srcFile.responseText;
				var txtArea = window.document.getElementById(container);
				/* parent.frames['inference_frame'].document.getElementById('program_container')
				|| parent.document.getElementById('inference_frame').contentDocument.getElementById('program_container')
				|| parent.document.getElementById('program_container'); */
				var lines = populateTable(allText);
				var noRows = 16;
				if ((lines * 2 > 16)) noRows = lines * 2;
				if ((lines * 2 > 30)) noRows = 30;
				txtArea.rows = noRows;
				txtArea.value = allText;
			}
		}
	}
	srcFile.send(null);
}

function loadFile(fileLocation,container) {
	var srcFile = new XMLHttpRequest();
	srcFile.open("GET", fileLocation, true);
	srcFile.onreadystatechange = function() {
		if (srcFile.readyState === 4) {
			if (srcFile.status === 200) {
				allText = srcFile.responseText;
				var txtArea = window.document.getElementById(container);
				/* parent.frames['inference_frame'].document.getElementById('program_container')
				|| parent.document.getElementById('inference_frame').contentDocument.getElementById('program_container')
				|| parent.document.getElementById('program_container'); */
				txtArea.value = allText;
                                txtArea.noResize = false;
				/* window.alert("sometext"); */
				var textHeight = txtArea.value.offsetHeight;
			        var myCodeMirror = CodeMirror.fromTextArea(txtArea,{lineNumbers: true, matchBrackets: true, mode: "text/x-csharp"});
			        myCodeMirror.setSize(null,null);
// parent.document.getElementById('inference_frame').noResize = false;
			}
		}
	}
	srcFile.send(null);
}

function clearResultFrame() {
	var fileName = getParam('ex');
	var fileType = getParam('type');
	var fileOptions = getParam('options');
	window.open("index.html?ex=" + fileName + "&type=" + fileType + "&options=" + fileOptions,"_self")
}

function addRow(data1, valid, startS, endS, focus) {

            var table = document.getElementById("tresult");

            var rowCount = table.rows.length;
            var row = table.insertRow(rowCount);

			var cell1 = row.insertCell(0);
			cell1.innerHTML = data1;
			/* var alink = document.createElement('a');
			alink.setAttribute('href', "javascript:selectText(" + startS + "," + endS + "," + focus + ")");
			alink.innerHTML = data1;
			cell1.appendChild(alink);  */


            var cell2 = row.insertCell(1);
			var alink = document.createElement('a');
			alink.setAttribute('href', "javascript:selectText(" + startS + "," + endS + "," + focus + ")");
            var img = document.createElement("img");
			if (valid)
				img.src = "imgs/greenchecksquare.bmp";
			else
				img.src = "imgs/redcrosssquare.bmp";
			alink.appendChild(img)
            cell2.appendChild(alink);
}

function populateTable(text){
var fileType = getParam('type');
        if (fileType === "c") {
                var token = "=======================";
                var meths = text.split(token);
                var noLines = text.split('\n').length;
                /*      window.alert("sometext"); */
                for (var i in meths) {
                        //window.alert(meths[i]);
                        if((meths[i].indexOf("[Verification for method: ")) != -1 || (meths[i].indexOf("Parser")) != -1 || (meths[i].indexOf("does not hold")) != -1){
                            if ((meths[i].indexOf("Parser")) != -1){
 addRow("Parser Error: \n 1. Events start with Upcase;\n 2. Try add parentheses",false, 0, text.length, 0);
}
                            else if ((meths[i].indexOf("does not hold")) != -1){
 addRow("Exceptions: \n(Assertion/Precondition/Undefined)",false, 0, text.length, 0);
}


                            else{
                                var lines = meths[i].split('\n');
                                var proc = lines[1].substring(26,lines[1].length-1);
                                var start = text.indexOf(" "+proc) - 25 - token.length - 1;
                                var end = start + meths[i].length  + token.length ;
                                var prefix = text.substring(0,text.indexOf(" "+proc)-10 - token.length);
                                var focus = prefix.split('\n').length;
/* var proc = meths[i].match("(.*?)\\$"); */
                                /*var proc = meths[i].match("[^\\$]+");
                                var start  = text.indexOf(token + proc+"$");
                                var end   = start + meths[i].length + token.length;
                                var prefix = text.substring(0,text.indexOf(token + proc));
                                var focus  = prefix.split('\n').length;
*/
/* window.alert(focus); */
                                if(meths[i].indexOf("Succeed") != -1){
                                        addRow(proc,true, start, end, focus/noLines);
                                }else{
                                        addRow(proc,false, start, end, focus/noLines);
                                }
                        }
                }
                }
                return meths.length;
        }



        else if (fileType === "txt") {

}
        else{
                token = "===================================="
                var meths = text.split(token);
                var noLines = text.split('\n').length;
                /*      window.alert("sometext"); */
                for (var i in meths) {
                        //addRow(meths[i],true);
                        //window.alert(meths[i]);
                    if((((meths[i].indexOf("Fail")) != -1)||((meths[i].indexOf("Succeed")) != -1))){
var lines = meths[i].split('\n');
var proc = lines[1].substring(0, lines[1].length-1);
                                var start = text.indexOf(proc)  - token.length - 1;
                                var end   = start + meths[i].length +token.length ;
                                var prefix = text.substring(0,text.indexOf(proc) - 1 - token.length);
                                var focus  = prefix.split("\n").length;
                                if(meths[i].indexOf("Succeed") != -1){
                                        addRow("Entailment",true, start, end, focus/noLines);
                                }else{
                                        addRow("Entailment",false, start, end, focus/noLines);
                                }
                        }
                   if ((meths[i].indexOf("Parser")) != -1){

addRow("Parser Error: \n 1. Events start with Upcase;\n 2. Try add parentheses",false, 0, text.length, 0);
                        }
                }
                return meths.length;
        }



}
/**
!!!Full processing file "../src/temp/.20719339.9853171.ss"
Parsing file "../src/temp/.20719339.9853171.ss" by default parser...

!!! processing primitives "["prelude.ss"]
Starting Omega...oc
Checking lemmas... DONE.

Checking procedure get$node...
Procedure get$node SUCCESS.

Checking procedure getA$node...
Procedure getA$node SUCCESS.

Checking procedure setA$node~int...
Procedure setA$node~int SUCCESS.

Checking procedure non_negative$node...
Procedure non_negative$node SUCCESS.

Checking procedure sset$node~int...
Procedure sset$node~int SUCCESS.
Stop Omega... 123 invocations
0 false contexts at: ()

!!! log(small):(0.12,493)
Total verification time: 0.24 second(s)
	Time spent in main process: 0.15 second(s)
	Time spent in child processes: 0.09 second(s)

*/

function loadResults(fileName) {
	/* parent.frames['inference_frame'].document.getElementById('program_container')
	|| parent.document.getElementById('inference_frame').contentDocument.getElementById('program_container')
	|| parent.document.getElementById('program_container'); */
	if (fileName != "") {
		var fileLocation = "src/temp/";
		var filePath = fileLocation + fileName;
		loadFileResult(filePath, 'result_container');
	} else {
		var txtArea = window.document.getElementById('result_container');
		txtArea.value = "";
	}
}

window.onload = function(evt) {
	// window.alert("sometext");
	var fileName = getParam('ex');
	var fileType = getParam('type');
	var fileOptions = getParam('options');
	var fileResult = getParam('result');
  // var programName = getParam('name');
	// window.alert("Bla");
	if (fileName != "0") {
		if(fileName.split(".").length > 1)
			{var fileLocation = "src/temp/";
		var filePath = fileLocation + fileName;
		loadFile(filePath,'program_container');
		}
		else {

                if (fileType == "ee") {fileLocation = "src/sleek/";}
                else if (fileType == "c") {fileLocation = "src/hip/";}
                else {fileLocation = "src/CSP/";}

                var filePath = fileLocation + fileName + "." + fileType;
                loadFile(filePath,'program_container');


		}
	} else {
		var txtArea = document.getElementById('program_container')
			|| document.getElementById('program_container');
		txtArea.value = "// Enter your own example here.";
	}
	loadResults(fileResult);
	var nameField = document.getElementById('program_name')
		|| document.getElementById('program_name');
	nameField.value = fileName;
	var typeField = document.getElementById('program_type')
		|| document.getElementById('program_type');
	typeField.value = fileType;
	var optionsField = document.getElementById('program_options')
		|| document.getElementById('program_options');
	optionsField.value = fileOptions;
  var selectedProgram = document.getElementById("select_program");
    selectedProgram.value = "verify.html?" + window.location.search.substring(1);
  // var programNameField = document.getElementById('programfullname')
  //     || document.getElementById('programfullname');
  // programNameField.innerHTML = "test";     /* ;programName; */
/* 	var resultFrame = window;
        resultFrame.location.href='result.html'; */
/*
document.ready(
function () {
	editAreaLoader.init({
		id: "program_container"
		,allow_resize: "both"
		,display:  "later"
		,word_wrap: true
		,syntax: "cpp"
	});
});
 window.alert("sometext");
	editAreaLoader.init({
		id: "result_container"
		,allow_resize: "both"
		,allow_toggle: false
		,display:  "later"
		,word_wrap: true
		,syntax: "cpp"
	});
*/
}

 function toggleVisibility(cb)
 {
  var x = document.getElementById("details_container");
  if(cb.checked==false)
   x.style.visibility = "hidden"; // or x.style.display = "none";
  else
   x.style.visibility = "visible"; //or x.style.display = "block";
 }

 function selectText(selectionStart, selectionEnd, focus){
	 var txtArea = document.getElementById('result_container');
 	 var cbDetails = document.getElementById('cb_details');
	 cbDetails.checked = true;
	 toggleVisibility(cbDetails);
	 txtArea.setSelectionRange(0, 0);
	 txtArea.focus();
	 //txtArea.setCursor(txtArea, selectionStart, selectionEnd);
	 txtArea.setSelectionRange(selectionStart, selectionEnd);
	 var h = txtArea.scrollHeight;
	 txtArea.scrollTop = (h * focus)-20;
	 /* txtArea.focus(); */
}
